package SVGU.testing;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Amazon {
	
	public static void main(String args[])
	{
		WebDriver driver = new ChromeDriver();
		
		try {
			System.out.println("starting the swaglab");
			driver.get("https://www.saucedemo.com/");
			System.out.println("Open the swaglab");
			
			driver.findElement(By.id("user-name")).sendKeys("standard_user");
			driver.findElement(By.id("password")).sendKeys("secret_sauce");
			
			driver.findElement(By.id("login-button")).click();
			String pageSource = driver.getPageSource();
			if(pageSource.contains("Sauce Labs Backpack")) {				
				System.out.println("Success");				
				driver.findElement(By.linkText("Sauce Labs Bike Light")).click();
				//driver.findElement(By.id("add-to-cart")).click();
				
			}else
			{
				System.out.println("UnSuccess");
			}
				
				
		}catch(Exception e)
		{
			System.out.println("Error : " +e.getMessage());
		}
		finally {
		//	driver.quit();
		}
		
		
		
	}

}
