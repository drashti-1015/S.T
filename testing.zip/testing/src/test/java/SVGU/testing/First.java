package SVGU.testing;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.chrome.ChromeDriver;

public class First {

	public static void main(String args[]) throws InterruptedException 
	{
		WebDriver driver = new ChromeDriver();
		System.out.println("Open the saucedemo");
		driver.get("https://www.saucedemo.com/");
		System.out.println("Url  : "+ driver.getCurrentUrl());
		
//		driver.navigate().to("https://www.google.com");
//		System.out.println("url : "+ driver.getCurrentUrl());
//		
//		driver.navigate().back();
//		System.out.println("url : "+ driver.getCurrentUrl());
//
//		String tab = driver.getWindowHandle();
//		System.out.println("tab : "+ tab);
//		driver.switchTo().newWindow(WindowType.WINDOW);
//		driver.get("https://google.com");
//		driver.close();
//		driver.quite();
		driver.findElement(By.id("user-name")).sendKeys("standard_user");
		driver.findElement(By.id("password")).sendKeys("secret_sauce");
		driver.findElement(By.name("login-button")).click();
//		driver.findElement(By.partialLinkText("Test")).click();
//		driver.findElement(By.id("add-to-cart")).click();
		driver.switchTo().newWindow(WindowType.TAB);
		driver.get("https://facebook.com");
		driver.quit();
		
		
//		driver.findElement(By.id("twotabsearchtextbox")).sendKeys("Tablets");
//		driver.findElement(By.id("nav-search-submit-button")).click();
//		driver.findElement(By.id("a-autoid-2-announce")).click();
//		driver.findElement(By.linkText("About Amazon")).click();
		
	}
	
}
