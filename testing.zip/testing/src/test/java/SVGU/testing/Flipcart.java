package SVGU.testing;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Flipcart {
	
	public static void main(String args[])
	{
		WebDriver driver = new ChromeDriver();
		
		try {
			System.out.println("Open flipcart ");
			driver.get("https://www.flipkart.com/");
			driver.manage().window().maximize();
			driver.findElement(By.name("q")).sendKeys("Tablet");
			driver.findElement(By.tagName("button")).click();
			
			driver.findElement(By.partialLinkText("Xiaomi Pad 7 12")).click();
			
			Thread.sleep(5000);
			
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		finally {
			driver.quit();
		}
		
	}
		
}
