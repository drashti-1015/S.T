package SVGU.testing;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class finalTest {
	
	
	public static void main(String args[])
	{
		WebDriver driver  = new FirefoxDriver();
		
		try
		{
			driver.manage().window().maximize();
			
			System.out.println("Open shopclue website");
			driver.get("http://www.shopclues.com");
			
			WebElement se = driver.findElement(By.id("autocomplete"));
			String value = "Mobile";
			se.sendKeys(value);
			driver.findElement(By.linkText("Search")).click();
			Thread.sleep(3000);
			String title = driver.getTitle();
			if(title.equals("Online Shopping Store | Buy Online: Mobiles Phone, Computers, Tablets Pc, Home Appliances | Lowest Price shop in India at ShopClues"))
			{
				System.out.println("Successfully");								
			}
			else
			{
				System.out.println("Not Successfully");	
			}
			Thread.sleep(5000);
			
		}catch(Exception e)
		{
			System.out.println("Error : " + e.getMessage());
		}
		finally {
			driver.quit();
		}
	}

}
