package SVGU.testing;

import java.sql.Time;
import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Second {
	
	public static void main(String args[])
	{
		WebDriver driver = new FirefoxDriver();
		System.out.println("Open the ShopClues website");
		driver.get("https://www.shopclues.com");
		System.out.println("Page is load");
		
		System.out.println("Write Mobile on Search");
		driver.findElement(By.id("autocomplete")).sendKeys("Mobile");
		driver.findElement(By.linkText("Search")).click();
		 
		String n  = driver.getTitle();
		if(n.equals("Online Shopping Store | Buy Online: Mobiles Phone, Computers, Tablets Pc, Home Appliances | Lowest Price shop in India at ShopClues"))
		{
			System.out.println("Successfully");
		}
		else
		{
			System.out.println("not Successfully");			
		}
			
		System.out.println("waiting");		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.quit();
		System.out.println("Success");
		
	}
	

}

